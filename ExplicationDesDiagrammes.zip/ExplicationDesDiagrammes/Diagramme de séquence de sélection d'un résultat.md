## IRAKOZE Olive Audrey  ## NGOUFACK ZEBAZE Judith Lisa

# Diagramme de séquence de sélection d'un résultat

Le diagramme met en évidence les interactions entre l'utilisateur (Parieur) et le système de pari en ligne (System) lorsqu'un parieur sélectionne un résultat pour un pari.
Étapes de l'Interaction
Sélection d'un Résultat : L'utilisateur (Parieur) sélectionne un résultat spécifique pour un pari.
Récupération des Résultats Possibles : Le système (System) récupère les résultats possibles associés au pari sélectionné par le parieur.

Affichage des Résultats :
Si des résultats sont disponibles, le système affiche ces résultats au parieur.
Sinon, le système informe le parieur qu'aucun résultat n'est disponible pour ce pari.
Alternatives
Si des résultats sont disponibles, le système les affiche au parieur.
Si aucun résultat n'est disponible, le système informe le parieur de cette absence.

