## IRAKOZE Olive Audrey  ## NGOUFACK ZEBAZE Judith Lisa

# Diagramme de séquence de  paris en ligne

Ce diagramme UML représente le processus de paris en ligne d'un système de paris.
Pari simple - Nominal
Le Parieur sélectionne le type de pari.
Le Système de Paris en Ligne présente un formulaire de pari au Parieur.
Le Parieur remplit et renvoie le formulaire.
Le Système vérifie le pari.
Un nouveau pari est créé.
Un ticket de pari est généré et associé au pari.
Le Parieur reçoit une confirmation que son pari a été créé.
Pari simple - Exceptionnel (pari invalide)
Le Parieur sélectionne le type de pari.
Le Système de Paris en Ligne présente un formulaire de pari au Parieur.
Le Parieur remplit et renvoie le formulaire.
Le Système détecte que le pari est invalide.
Le Parieur reçoit un message indiquant que son pari est invalide.
Pari simple - Exceptionnel (Annulation pari)
Le Parieur demande l'annulation d'un pari existant.
Le Système de Paris en Ligne présente un formulaire d'annulation au Parieur.
Le Parieur remplit et renvoie le formulaire.
Le Système vérifie l'existence du pari à annuler.
Le pari est supprimé du système.
Le ticket associé au pari est également supprimé.
Le Parieur reçoit une confirmation que son ticket de pari a été supprimé.
