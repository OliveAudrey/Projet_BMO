## IRAKOZE Olive Audrey  ## NGOUFACK ZEBAZE Judith Lisa

# Diagramme d'état

Ce diagramme d'état représente le cycle de connexion et de déconnexion d'un système. Il illustre les états possibles du système, ainsi que les transitions entre ces états en fonction des événements.

États
NonConnecte : L'état initial du système où aucune connexion n'est établie.
AttenteConnexion : L'état où le système attend une tentative de connexion.
Connecte : L'état où le système est connecté et prêt à fonctionner.
AttenteDeconnexion : L'état où le système attend une demande de déconnexion.

Transitions
[*] --> NonConnecte : Transition initiale depuis un état indéterminé vers l'état NonConnecte.
NonConnecte --> AttenteConnexion : Transition lorsque le système est prêt à accepter une connexion.
AttenteConnexion --> Connecte : Transition réussie vers l'état Connecte en cas de connexion réussie.
AttenteConnexion --> NonConnecte : Transition vers l'état NonConnecte en cas d'échec de la connexion.
Connecte --> AttenteDeconnexion : Transition vers l'état AttenteDeconnexion lorsque le système est connecté et attend une demande de déconnexion.
AttenteDeconnexion --> NonConnecte : Transition vers l'état NonConnecte en cas de déconnexion.

