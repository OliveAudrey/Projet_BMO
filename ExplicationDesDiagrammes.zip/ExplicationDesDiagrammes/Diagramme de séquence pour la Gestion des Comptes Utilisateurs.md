## IRAKOZE Olive Audrey  ## NGOUFACK ZEBAZE Judith Lisa


# Diagramme de séquence pour la Gestion des Comptes Utilisateurs

Ce diagramme UML vise à illustrer les interactions entre un utilisateur (Parieur) et un système de paris en ligne (Système) pour la gestion des comptes utilisateurs, en mettant en lumière les scénarios nominaux et exceptionnels lors du rechargement de jetons et de la vérification du solde.
Lorsque l'utilisateur souhaite recharger ses jetons, le processus suit les étapes suivantes :
Demande de Rechargement de Jetons : L'utilisateur (Parieur) envoie une demande au système pour recharger ses jetons.
Traitement de la Demande de Recharge : Le système de paris en ligne (Système) traite la demande de recharge de jetons.
Confirmation de la Recharge : Une fois la demande traitée avec succès, le système envoie une confirmation de la recharge à l'utilisateur.
Interactions Exceptionnelles (Solde Insuffisant)
Dans le cas où l'utilisateur n'a pas un solde suffisant pour placer un pari, le processus suit les étapes suivantes :
Demande de Pari : L'utilisateur (Parieur) envoie une demande de pari au système.
Vérification du Solde : Le système vérifie le solde disponible pour l'utilisateur.
Notification de Solde Insuffisant : Si le solde disponible est insuffisant pour placer le pari, le système envoie une notification à l'utilisateur indiquant que son solde est insuffisant pour effectuer l'action demandée.
