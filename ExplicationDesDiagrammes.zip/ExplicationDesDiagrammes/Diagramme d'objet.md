## IRAKOZE Olive Audrey  ## NGOUFACK ZEBAZE Judith Lisa

# Diagramme d'objet

Ce diagramme d'objet représente un système de paris sportifs, mettant en scène un parieur, un événement sportif, un type de pari, un ticket de pari, un bookmaker et un algorithme de cotes.

Objets Principaux :
1. Parieur :
Représente un individu participant aux paris sportifs.
Possède un capital initial et des jetons pour effectuer des paris.

2. Événement Sportif :
Définit un événement sportif spécifique, tel que le football.
Comprend des options de pari telles que le vainqueur ou le match nul.

3. Type de Pari :
Décrit le type de pari effectué, par exemple, un pari simple.

4. Ticket :
Représente un billet de pari soumis par le parieur pour un événement sportif spécifique.
Contient des informations sur l'événement sportif sélectionné, le type de pari, le résultat parie, et le montant misé.

5. Bookmaker :
Entité fournissant les cotes et les paramètres pour les paris.
Détermine les cotes pour les différents événements sportifs et types de paris.

6. Algorithme de Cotes :
Responsable du calcul des cotes pour les événements sportifs.
Utilisé par le bookmaker pour fournir des cotes aux parieurs.

Interactions :
Le Parieur soumet un Ticket de pari, ce qui débite son capital.
Le Ticket de pari sélectionne un Événement Sportif et un Type de Pari.
Les Bookmakers déterminent les paramètres et les cotes pour les Événements Sportifs et les Types de Pari.
L'Algorithme de Cotes est utilisé pour calculer les cotes des Événements Sportifs.