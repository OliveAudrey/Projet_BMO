## IRAKOZE Olive Audrey  ## NGOUFACK ZEBAZE Judith Lisa

# Diagramme de cas d'utilisation 

Ce diagramme de cas d'utilisation représente les principales fonctionnalités du système "Pari sportif en ligne", qui permet aux bookmakers et parieurs d'interagir avec la plateforme pour placer et gérer des paris sportifs.

Acteurs
Bookmaker
Le bookmaker est un acteur externe qui fournit les cotes, définit les paramètres des événements et limite le montant maximal pouvant être misé sur un événement.

Parieur
Le parieur est un utilisateur de la plateforme qui s'inscrit ou se connecte pour accéder aux fonctionnalités de sélection d'événements sportifs, de choix de paris, de spécification des résultats et de soumission des paris.

Cas d'utilisation
Déterminer les évènements (u)
Le bookmaker utilise cette fonctionnalité pour définir les événements sur lesquels les parieurs peuvent placer des paris. Cela peut inclure des événements sportifs tels que des matchs de football, de basketball, des courses de chevaux, etc.

Définir les paramètres relatifs à ces évènements (u1)
Cette fonctionnalité permet au bookmaker de spécifier les paramètres spécifiques à chaque événement, tels que les cotes, les règles de mise, etc.

Limiter le montant maximal (u2)
Le bookmaker peut limiter le montant maximal qu'un parieur peut miser sur un événement pour gérer les risques et les pertes potentielles.

Inscription/connexion (u4)
Les parieurs utilisent cette fonctionnalité pour s'inscrire à la plateforme ou se connecter à leur compte existant afin d'accéder aux fonctionnalités de pari.

Sélectionner évènement sportif (u6)
Les parieurs peuvent parcourir les événements sportifs disponibles et sélectionner ceux sur lesquels ils souhaitent parier.

Sélectionner un pari (u7)
Une fois un événement sélectionné, les parieurs peuvent choisir parmi les différents types de paris disponibles, tels que le vainqueur du match, le nombre de buts marqués, etc.

Sélectionner le résultat du pari (u8)
Après avoir choisi le type de pari, les parieurs spécifient le résultat sur lequel ils parient, par exemple l'équipe gagnante, le nombre de buts, etc.

Montant à parier (u9)
Les parieurs saisissent le montant qu'ils souhaitent parier sur le résultat sélectionné.

Soumission du ticket (u10)
Une fois toutes les sélections faites, les parieurs soumettent leur ticket de pari pour validation et traitement par le système.

