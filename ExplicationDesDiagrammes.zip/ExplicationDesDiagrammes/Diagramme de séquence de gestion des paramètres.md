## IRAKOZE Olive Audrey  ## NGOUFACK ZEBAZE Judith Lisa

# Diagramme de séquence de gestion des paramètres

Ce diagramme UML représente le processus de gestion des paramètres par le bookmaker dans un système de paris en ligne, en incluant les scénarios nominaux et exceptionnels.
Gestion des paramètres par le bookmaker - Nominal (définition des paramètres)
Ce groupe représente le scénario nominal où le bookmaker définit les paramètres du système de paris en ligne.
Actions:
Le Bookmaker envoie une demande de définition des paramètres au système.
Le système envoie un formulaire de définition des paramètres au bookmaker.
Le bookmaker remplit le formulaire et le renvoie au système.
Le système vérifie le formulaire et confirme la création des paramètres.
Résultat:
Le système informe le bookmaker que la définition des paramètres a été créée avec succès.
Gestion des paramètres par le bookmaker - Exceptionnel (Formulaire incorrect)
Ce groupe représente le scénario où le formulaire de définition des paramètres envoyé par le bookmaker est incorrect.
Actions:
Le Bookmaker envoie une demande de définition des paramètres au système.
Le système envoie un formulaire de définition des paramètres au bookmaker.
Le bookmaker remplit le formulaire et le renvoie au système.
Le système vérifie le formulaire et détecte une saisie incorrecte.
Résultat:
Le système informe le bookmaker de l'échec de la saisie incorrecte du formulaire.
