# IRAKOZE Olive Audrey  ## NGOUFACK ZEBAZE Judith Lisa

# Diagramme de classes

Ce diagramme de classe représente le système d'un système de paris sportifs en ligne. Il modélise les entités principales et leurs relations, fournissant une vue structurée des différentes composantes du système.

Classes

Parieur
Attributs : parieurId (identifiant unique du parieur), jetons (solde de jetons du parieur), nom, prénom, pseudo, email, mot de passe.
Méthodes : faire_un_pari().

Pari_sportif
Attributs : pariSportifId (identifiant unique du pari sportif), montant (montant du pari), typesPari (type de pari).
Méthodes : AjouterPari(), SupprimerPari().

Ticket
Attributs : ticketId (identifiant unique du ticket), montantMax (montant maximal autorisé pour le pari), pariId (identifiant du pari associé), miseJouee (montant misé), cote (cote du pari).
Méthodes : Create(), Remove(), Update(), Delete().

Evenement
Attributs : evenementId (identifiant unique de l'événement), dateEvenement (date de l'événement).
Méthodes : Create(), Remove(), Update(), Delete().

Sport
Attributs : sportId (identifiant unique du sport), typesSports (types de sports), regles (règles du sport).
Méthodes : CreateSport(), RemoveSport(), UpdateSport(), DeleteSport(), CreateRegles(), RemoveRegles(), UpdateRegles(), DeleteRegles().

Bookmaker
Attributs : bookmakerId (identifiant unique du bookmaker), nom.

Relations
Un Parieur peut faire plusieurs Pari_sportif, et un Pari_sportif peut être associé à plusieurs Parieur.
Un Pari_sportif peut être lié à un Ticket, mais un Ticket est associé à un seul Pari_sportif.
Un Pari_sportif peut être associé à plusieurs Evenement, mais un Evenement est lié à un seul Pari_sportif.
Un Sport est lié à plusieurs Evenement, mais un Evenement est associé à un seul Sport.
Un Evenement est proposé par un Bookmaker. 