## IRAKOZE Olive Audrey  ## NGOUFACK ZEBAZE Judith Lisa

# Diagramme de séquence de gestion des événements sportifs

Ce diagramme de séquence représente le processus de gestion des événements sportifs dans un système de paris en ligne, mettant en interaction un Bookmaker avec le système.
Gestion des événements sportifs – Nominal
Dans ce scénario nominal, le processus commence lorsque le Bookmaker propose un nouvel événement sportif au système. Le système répond en fournissant un formulaire de création d'événement au Bookmaker. Le Bookmaker remplit le formulaire et le renvoie au système. Ensuite, le système vérifie les informations fournies dans le formulaire et procède à la création de l'événement. Une fois l'événement créé avec succès, le système envoie une confirmation au Bookmaker.
Gestion des événements sportifs - Exceptionnel
Dans ce scénario exceptionnel, le processus démarre de la même manière, avec le Bookmaker proposant un nouvel événement sportif. Cependant, lors de la vérification du formulaire par le système, il est détecté que l'événement proposé existe déjà dans le système. Par conséquent, le système renvoie une erreur au Bookmaker, l'informant que l'événement est déjà existant, et le processus de création est interrompu.
