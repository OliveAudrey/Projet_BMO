package com.yourcompany.onelinebetting.model;


import javax.persistence.*;

import org.openxava.annotations.*;

import lombok.*;

@Entity
@Getter @Setter

public class Parieur {
	
	@Id
	@Column(length=6)
	int parieurId;
	
	@Column(length=50)
	@Required
	String nom;
	String prenom;
	String jetons;
	String email;
	String password;
	
	@ManyToOne(fetch=FetchType.LAZY)
	//@DescriptionsList
	PariSportif paisportif;
	
	  
}
