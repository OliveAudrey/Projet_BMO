package com.yourcompany.onelinebetting.model;

import java.util.*;

import javax.persistence.*;

import org.openxava.annotations.*;

import lombok.*;

@Entity
@Getter @Setter

public class Evenement {
	
	@Id
	@Column(length=8)
	int evenementId;
	
	@Column(length=50)
	@Required
	String resultat;
	
	@Column(length=50)
	@Required
	Date DateEvenement;
	
	
    @ManyToOne(fetch=FetchType.LAZY, 
    optional=false)
    private Sport sport;

}
