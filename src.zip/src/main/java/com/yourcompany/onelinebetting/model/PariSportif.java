package com.yourcompany.onelinebetting.model;

import javax.persistence.*;

import org.openxava.annotations.*;

import lombok.*;

@Entity
@Getter @Setter

public class PariSportif {
	
	@Id
	@Column(length=8)
	int pariSportifId;
	int montant;
	
	@Column(length=12)
	@Required
	String typesPari;
	

}
