package com.yourcompany.onelinebetting.model;

import javax.persistence.*;

import org.openxava.annotations.*;

import lombok.*;

@Entity
@Getter @Setter

public class Bookmaker {
	@Id
	@Column(length=4)
	int bookmakerId;
	
	@Column(length=50)
	@Required
	String nom;
	
	@ManyToOne(fetch=FetchType.LAZY, 
	optional=false)
    private Evenement evenement;

}
