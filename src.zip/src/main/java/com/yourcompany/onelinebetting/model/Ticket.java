package com.yourcompany.onelinebetting.model;

import javax.persistence.*;

import org.openxava.annotations.*;

import lombok.*;

@Entity
@Getter @Setter

public class Ticket {
	
	@Id
	@Column(length=9)
	int ticketId;
	int montantMax;
	int pariId;
	int miseJouee;
	
	@Column(length=12)
	@Required
	Float cote;
	
	@ManyToOne 
	private PariSportif parisportif;

	
	@ManyToOne 
	private Evenement evenement;
	


}
