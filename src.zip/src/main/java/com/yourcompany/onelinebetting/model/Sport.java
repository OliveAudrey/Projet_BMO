package com.yourcompany.onelinebetting.model;

import javax.persistence.*;

import org.openxava.annotations.*;

import lombok.*;

@Entity
@Getter @Setter

public class Sport {
	
	@Id
	@Column(length=4)
	int sportId;
	
	@Column(length=50)
	@Required
	String typesSport;
	String regles;

}
